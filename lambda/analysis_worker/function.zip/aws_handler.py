import datetime
import json
import os
import requests
import boto3

# Standard AWS Initialization
# No custom scripts.db_config needed; Lambda handles credentials via Roles
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = os.environ.get('DYNAMODB_TABLE', 'Summaries')
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    """
    AWS Analysis Worker: 
    Triggered by a Cloud Bridge or DynamoDB Stream.
    Uses Mistral AI and saves results directly to the Cloud DynamoDB.
    """
    mistral_key = os.environ.get('MISTRAL_API_KEY')
    
    # 1. Handle Input (Unify: Cloud Bridge vs direct Lambda Invoke)
    # AWS events usually pass data directly in the event or under 'body'
    body = event.get('body', event) 
    fid = body.get('feedback_id', 'unknown')
    raw_text = body.get('text', '')

    if not raw_text:
        return {"status": "error", "message": "No text provided", "summary": "N/A"}

    try:
        # 2. Combined AI Analysis (Mistral Medium)
        m_url = "https://api.mistral.ai/v1/chat/completions"
        prompt = (
            f"Analyze this feedback: '{raw_text}'. "
            "1. Translate it to English. "
            "2. Determine sentiment (POSITIVE/NEGATIVE/NEUTRAL). "
            "3. Summarize in 10 words. "
            "Return a JSON object with keys: 'translated', 'sentiment', 'summary'."
        )
        
        m_body = {
            "model": "mistral-medium-latest",
            "messages": [{"role": "user", "content": prompt}],
            "response_format": {"type": "json_object"}
        }
        
        res = requests.post(m_url, 
                            headers={'Authorization': f'Bearer {mistral_key}'}, 
                            json=m_body, timeout=15)
        res.raise_for_status()
        
        # Parse the AI content
        ai_response = res.json()
        analysis = json.loads(ai_response['choices'][0]['message']['content'])

        # 3. Create Cloud-Ready Payload
        payload = {
            "feedback_id": fid,
            "sentiment": analysis.get('sentiment', 'NEUTRAL').upper(),
            "summary": analysis.get('summary', 'No summary available'),
            "translated_text": analysis.get('translated', raw_text),
            "timestamp": datetime.datetime.now().isoformat(),
            "status": "COMPLETED"
        }

        # 4. Save to Cloud DynamoDB
        # We removed the local JSON file saving (os.path.join) because 
        # Lambda's disk is ephemeral and we want to use DynamoDB as the source.
        table.put_item(Item=payload)

        # 5. Return JSON Response
        return {
            "status": "success",
            "feedback_id": fid,
            "summary": payload["summary"],
            "sentiment": payload["sentiment"],
            "translated_text": payload["translated_text"]
        }

    except Exception as e:
        # CloudWatch will capture this print statement
        print(f"❌ AWS Analysis Error for {fid}: {str(e)}")
        return {
            "status": "error", 
            "message": str(e), 
            "summary": "Error during analysis", 
            "sentiment": "NEUTRAL"
        }