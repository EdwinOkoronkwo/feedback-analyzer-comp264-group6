import json
import time
import os
import requests
import boto3
import logging

# Initialize AWS Clients
dynamodb = boto3.resource('dynamodb')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    AWS Hybrid Worker: 
    Consolidates OCR, Labels, and Translation into a final 'Fat Document'.
    Uses Mistral (Small/Medium/Large) for final summary and sentiment.
    """
    # 1. Configuration from Environment Variables
    api_key = os.environ.get('MISTRAL_API_KEY')
    # Default to 'mistral-medium-latest' but can be 'mistral-small-latest' or 'mistral-large-latest'
    model_tier = os.environ.get('MISTRAL_MODEL', 'mistral-medium-latest')
    table_name = os.environ.get('SUMMARIES_TABLE', 'Summaries')
    table = dynamodb.Table(table_name)

    # 2. Parse Input (Usually passed from the Pipeline/Bridge)
    body = event.get('body', event)
    fid = body.get('feedback_id', 'unknown')
    user_id = body.get('user_id', 'anonymous')
    raw_text = body.get('text', '')
    text_to_analyze = body.get('translated_text') or raw_text

    if not raw_text:
        return {"status": "error", "message": "No text provided to worker"}

    # 3. AI Analysis via Mistral API
    url = "https://api.mistral.ai/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    prompt = (
        f"Analyze this feedback: '{text_to_analyze}'. "
        "Return a JSON object with two keys: "
        "'summary' (one short sentence) and 'sentiment' (POSITIVE, NEGATIVE, or NEUTRAL)."
    )
    
    payload = {
        "model": model_tier,
        "messages": [{"role": "user", "content": prompt}],
        "response_format": {"type": "json_object"} 
    }

    try:
        logger.info(f"🌟 [AWS Worker] Calling {model_tier} for ID: {fid}...")
        response = requests.post(url, json=payload, headers=headers, timeout=15)
        response.raise_for_status()
        
        ai_data = response.json()
        raw_content = ai_data['choices'][0]['message']['content'].strip()

        # Clean Markdown backticks if Mistral included them
        if raw_content.startswith("```"):
            raw_content = raw_content.split("json")[-1].strip("`").strip()

        ai_content = json.loads(raw_content)
        summary = ai_content.get('summary', 'No summary generated.')
        sentiment = ai_content.get('sentiment', 'NEUTRAL').upper()

        # 4. Save the Final Document to Cloud DynamoDB
        logger.info(f"💾 SAVING FINAL RECORD -> Table: {table_name} | Key: {fid}")

        table.put_item(Item={
            'feedback_id': fid,          # PRIMARY KEY
            'user_id': user_id,
            'text': raw_text,
            'translated_text': body.get('translated_text'),
            'summary': summary,
            'sentiment': sentiment,
            'labels': body.get('labels', []),
            'ocr_details': body.get('ocr_details', {}),
            'processed_at': str(time.time()),
            'status': 'COMPLETED',
            'model_used': model_tier
        })
        
        return {
            "status": "success", 
            "feedback_id": fid, 
            "summary": summary, 
            "sentiment": sentiment
        }

    except Exception as e:
        logger.error(f"❌ [AWS Worker] Error: {str(e)}")
        return {"status": "error", "message": str(e)}