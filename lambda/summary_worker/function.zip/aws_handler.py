import json
import time
import os
import urllib3 # Built-in, no installation needed
import boto3
import logging

# Initialize AWS Clients outside the handler for speed
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')
http = urllib3.PoolManager()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # 1. Configuration
    api_key = os.environ['MISTRAL_API_KEY']
    model_tier = os.environ.get('MISTRAL_MODEL', 'mistral-medium-latest')
    table_name = os.environ.get('SUMMARIES_TABLE', 'Analysis_Summaries')
    table = dynamodb.Table(table_name)

    # 2. Parse Input (S3 Event or Direct)
    if 'Records' in event:
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        # Get Metadata
        s3_metadata = s3_client.head_object(Bucket=bucket, Key=key)
        metadata = s3_metadata.get('Metadata', {})

        # AWS S3 flattens metadata keys to lowercase automatically!
        fid = metadata.get('feedback_id') or metadata.get('feedback-id') or 'unknown_id'
        user_id = metadata.get('user_id', 'anonymous')

        print(f"DEBUG: Found Metadata: {metadata}")
        print(f"DEBUG: Using ID: {fid}")
        
        # Get actual text from file
        obj = s3_client.get_object(Bucket=bucket, Key=key)
        raw_text = obj['Body'].read().decode('utf-8')
    else:
        body = event.get('body', event)
        fid = body.get('feedback_id', 'unknown_id')
        user_id = body.get('user_id', 'anonymous')
        raw_text = body.get('text', '')

    if not raw_text:
        raise ValueError(f"No text found for feedback_id: {fid}")

    # 3. AI Analysis via Mistral (using urllib3)
    url = "https://api.mistral.ai/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    prompt = (
        f"Analyze: '{raw_text}'. Return JSON with keys: "
        "'summary' (one sentence) and 'sentiment' (POSITIVE, NEGATIVE, or NEUTRAL)."
    )
    
    payload = json.dumps({
        "model": model_tier,
        "messages": [{"role": "user", "content": prompt}],
        "response_format": {"type": "json_object"}
    }).encode('utf-8')

    logger.info(f"🌟 Calling Mistral for ID: {fid}")
    resp = http.request('POST', url, body=payload, headers=headers, timeout=20.0)
    
    if resp.status != 200:
        raise Exception(f"Mistral Error: {resp.status} - {resp.data.decode('utf-8')}")
    
    # Parse Mistral result
    ai_raw = json.loads(resp.data.decode('utf-8'))
    ai_content = json.loads(ai_raw['choices'][0]['message']['content'])

    # 4. Save to DynamoDB
    logger.info(f"💾 Saving to {table_name}")
    table.put_item(Item={
        'feedback_id': fid,
        'user_id': user_id,
        'text': raw_text,
        'summary': ai_content['summary'],
        'sentiment': ai_content['sentiment'].upper(),
        'processed_at': str(time.time()),
        'status': 'COMPLETED'
    })
    
    return {"status": "success", "feedback_id": fid}