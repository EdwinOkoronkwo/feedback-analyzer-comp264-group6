
import json
import time
import boto3

# Initialize AWS Clients
translate = boto3.client('translate')
dynamodb = boto3.resource('dynamodb')

# Tables
OCR_TABLE = dynamodb.Table('Analysis_OCR')
METADATA_TABLE = dynamodb.Table('Metadata')

def lambda_handler(event, context):
    # 1. Get the Feedback ID from the Master Worker
    fid = event.get('feedback_id', 'unknown')
    print(f"🌍 AWS Translate triggered for: {fid}")

    try:
        # 2. Fetch the text extracted by the OCR worker
        response = OCR_TABLE.get_item(Key={'feedback_id': fid})
        source_text = response.get('Item', {}).get('text')

        if not source_text:
            print(f"⚠️ No text found for {fid} in OCR table.")
            return {"status": "skipped", "reason": "no_text"}

        # 3. Perform AWS Native Translation (Auto-detect source language)
        print(f"🛰️ Calling AWS Translate for {fid}...")
        result = translate.translate_text(
            Text=source_text,
            SourceLanguageCode='auto',
            TargetLanguageCode='en'
        )
        
        translated_text = result.get('TranslatedText')

        # 4. Save result to the Metadata table
        METADATA_TABLE.put_item(Item={
            'feedback_id': fid,
            'type': 'translation_en',
            'translated_text': translated_text,
            'processed_at': str(time.time()),
            'engine': 'aws-translate-native'
        })
        
        print(f"✅ Successfully translated {fid} and saved to Metadata.")
        
        return {
            "status": "success",
            "feedback_id": fid,
            "translated_text": translated_text
        }

    except Exception as e:
        print(f"❌ AWS Translate Error for {fid}: {str(e)}")
        return {"status": "error", "message": str(e)}