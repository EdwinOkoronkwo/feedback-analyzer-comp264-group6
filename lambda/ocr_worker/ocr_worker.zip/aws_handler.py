import boto3
import json
import os
import time

# Initialize Clients
textract = boto3.client('textract', region_name='us-east-1')
s3 = boto3.client('s3', region_name='us-east-1')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
lambda_client = boto3.client('lambda', region_name='us-east-1')

def lambda_handler(event, context):
    fid = 'unknown'
    try:
        # 1. Parse S3 Event (Mimicked by your Bridge)
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        full_key = record['s3']['object']['key'] 
        
        filename = full_key.split('/')[-1]
        fid = filename.rsplit('.', 1)[0]
        
        # ✅ FIX: Handle JPG/JPEG for the new Kaggle dataset
        is_text_file = full_key.lower().endswith('.txt')
        is_image = any(full_key.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg'])

        print(f"📸 OCR Worker: Processing {fid} (Is Image: {is_image})")

        full_text = ""

        # 2. 🎯 THE BYPASS: Text vs Image
        if is_text_file:
            print(f"📄 Reading raw text from S3 for {fid}")
            response = s3.get_object(Bucket=bucket, Key=full_key)
            full_text = response['Body'].read().decode('utf-8')
        elif is_image:
            print(f"🔍 Running Textract OCR for {fid}")
            response = textract.detect_document_text(
                Document={'S3Object': {'Bucket': bucket, 'Name': full_key}}
            )
            # Textract returns 'Blocks'; we join 'LINE' types for readable sentences
            detected_text = [item['Text'] for item in response['Blocks'] if item['BlockType'] == 'LINE']
            full_text = " ".join(detected_text)
        else:
            full_text = "Unsupported file format."

        if not full_text.strip():
            full_text = "No readable text found."

        # 3. DynamoDB: Update the main table (Analysis_Summaries) 
        # 🎯 FIX: Ensuring 'status' is updated so the test script poller detects it
        table = dynamodb.Table('Analysis_Summaries')
        table.update_item(
            Key={'feedback_id': fid},
            UpdateExpression="SET #s = :stat, raw_text = :txt, #m = :msg",
            ExpressionAttributeNames={'#s': 'status', '#m': 'master'},
            ExpressionAttributeValues={
                ':stat': 'OCR_COMPLETED',
                ':txt': full_text,
                ':msg': "OCR Complete. Sending to Analysis Worker."
            }
        )
        
        # 4. RELAY: Trigger Analysis Worker (Baton Pass)
        lambda_client.invoke(
            FunctionName='analysis_worker',
            InvocationType='Event',
            Payload=json.dumps({"feedback_id": fid, "text": full_text}).encode('utf-8')
        )
        
        return {"status": "success", "feedback_id": fid}

    except Exception as e:
        print(f"❌ OCR Error for {fid}: {str(e)}")
        # Log failure to table so poller doesn't hang
        try:
            dynamodb.Table('Analysis_Summaries').update_item(
                Key={'feedback_id': fid},
                UpdateExpression="SET #s = :err",
                ExpressionAttributeNames={'#s': 'status'},
                ExpressionAttributeValues={':err': 'OCR_FAILED'}
            )
        except:
            pass
        return {"status": "error", "message": str(e)}