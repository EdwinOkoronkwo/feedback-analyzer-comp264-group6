import boto3
import json
import os

# Initialize Cloud Clients
textract = boto3.client('textract', region_name='us-east-1')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
lambda_client = boto3.client('lambda', region_name='us-east-1')
# 🎯 ENSURE: Table name matches your cloud DB
table = dynamodb.Table('Analysis_OCR') 

def lambda_handler(event, context):
    try:
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        
        # 🎯 THIS IS THE FULL PATH: "uploads/admin_6cfd607a.jpg"
        full_key = record['s3']['object']['key'] 
        
        # 🎯 FIX 1: Extract ID correctly from the full path
        # key.split('/')[-1] gets "admin_6cfd607a.jpg"
        filename = full_key.split('/')[-1]
        fid = filename.rsplit('.', 1)[0] # "admin_6cfd607a"

        print(f"📸 OCR Worker starting for: {fid}")

        # 🎯 FIX 2: Pass the FULL KEY to Textract
        response = textract.detect_document_text(
            Document={'S3Object': {'Bucket': bucket, 'Name': full_key}} # Use full_key here
        )
        
        
        # 3. EXTRACT TEXT
        detected_text = [
            item['Text'] for item in response['Blocks'] 
            if item['BlockType'] == 'LINE'
        ]
        full_text = " ".join(detected_text)

        if not full_text.strip():
            full_text = "No readable text found in image."

        # 4. SAVE TO DYNAMODB (Cloud Version of 'Metadata' table)
        table.put_item(Item={
            'feedback_id': fid,          
            'text': full_text,           # UI looks for 'text'
            'status': 'COMPLETED',       # UI looks for 'status'
            'filename': filename
        })
        
        print(f"✅ OCR Success for {fid}")

        # 5. THE CLOUD HANDOFF (Triggering the Summarizer)
        payload = {
            "body": {
                "feedback_id": fid,
                "text": full_text,
                "user_id": fid.split('_')[0] if '_' in fid else 'admin'
            }
        }

        # We 'kick' the summarizer and end our job immediately
        lambda_client.invoke(
            FunctionName='summary_worker',
            InvocationType='Event', # Asynchronous
            Payload=json.dumps(payload).encode('utf-8')
        )
        
        return {"status": "success", "feedback_id": fid}

    except Exception as e:
        print(f"❌ Cloud OCR Error for {fid if 'fid' in locals() else 'unknown'}: {str(e)}")
        return {"status": "error", "message": str(e)}