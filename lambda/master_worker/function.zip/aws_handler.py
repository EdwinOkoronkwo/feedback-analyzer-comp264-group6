import json
import boto3

lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    print(f"📥 Master Received Event: {json.dumps(event)}")
    
    try:
        # Extract filename from the S3 event
        s3_key = event['Records'][0]['s3']['object']['key']
        fid = s3_key.split('/')[-1].split('.')[0]
        print(f"🎯 Target Feedback ID: {fid}")

        # Invoke OCR and WAIT for a response (Synchronous) 
        # This prevents the "Silent Timeout" in your test script
        print(f"⚡ Triggering ocr_worker...")
        response = lambda_client.invoke(
            FunctionName='ocr_worker',
            InvocationType='RequestResponse', 
            Payload=json.dumps({'feedback_id': fid})
        )
        
        # Read the result to see if OCR actually worked
        result = json.loads(response['Payload'].read().decode('utf-8'))
        print(f"📸 OCR Worker Response: {result}")

        return {"status": "success", "fid": fid}

    except Exception as e:
        print(f"❌ Master Error: {str(e)}")
        return {"status": "error", "message": str(e)}