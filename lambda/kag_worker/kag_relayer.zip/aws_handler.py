import json
import os
import boto3
import time

# Initialize AWS Clients
dynamodb = boto3.resource('dynamodb')
lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    """
    KAG Relayer: Standardizes Kaggle Tobacco samples into the Feedback Pipeline.
    """
    fid = event.get('feedback_id', f"kag_batch_{int(time.time())}")
    bucket = event.get('bucket', 'comp264-edwin-1772030214')
    image_url = event.get('image_url', '')
    folder = event.get('folder', 'Unknown')

    # Extract S3 Key from URL: s3://bucket/key -> key
    s3_key = image_url.replace(f"s3://{bucket}/", "")

    try:
        print(f"🏛️ KAG Relayer: Received {fid} from {folder} folder.")

        # 1. Initialize Record in Analysis_Summaries
        # This is what your test script poller is watching
        table = dynamodb.Table('Analysis_Summaries')
        table.put_item(Item={
            'feedback_id': fid,
            'status': 'PROCESSING_BATCH',
            'dataset_type': f'KAG_{folder.upper()}',
            'image_path': image_url,
            'timestamp': str(int(time.time())),
            'master': f"Kaggle Relayer: Starting OCR on {folder} document."
        })

        # 2. 🎯 THE BATON PASS: Construct S3 Event for ocr_worker
        ocr_payload = {
            "Records": [{
                "s3": {
                    "bucket": {"name": bucket},
                    "object": {"key": s3_key}
                }
            }]
        }

        # 3. Trigger OCR Worker
        # This continues the chain: Bridge -> Relayer -> OCR -> Analysis
        lambda_client.invoke(
            FunctionName='ocr_worker', 
            InvocationType='Event',
            Payload=json.dumps(ocr_payload).encode('utf-8')
        )

        return {
            "status": "success",
            "feedback_id": fid,
            "next_step": "ocr_worker_triggered"
        }

    except Exception as e:
        print(f"❌ KAG Relayer Error: {str(e)}")
        return {"status": "error", "message": str(e)}