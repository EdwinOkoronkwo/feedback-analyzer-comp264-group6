import json
import boto3
import time

# Initialize AWS Clients
s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    # 1. Extract Info
    fid = event.get('feedback_id', f"kag_batch_{int(time.time())}")
    bucket = event.get('bucket', 'comp264-edwin-1772030214')
    image_url = event.get('image_url', '')
    folder = event.get('folder', 'Unknown')
    s3_key = image_url.replace(f"s3://{bucket}/", "")

    try:
        print(f"🏛️ KAG Worker: Processing {fid}")

        # 2. Seed DynamoDB
        table = dynamodb.Table('Analysis_Summaries')
        table.put_item(Item={
            'feedback_id': fid,
            'status': 'PROCESSING_KAG',
            'dataset_type': f'KAG_{folder.upper()}',
            'image_path': image_url,
            'timestamp': str(time.time()),
            'master': f"KAG Worker initialized {folder} document."
        })
        print(f"✅ [CHECKPOINT 1] DB Seeded for {fid}")

        # 3. Determine file type and route the baton
        file_ext = s3_key.split('.')[-1].lower()

        if file_ext == 'txt':
            # 🏃 SHORTCUT: Read text and go straight to Analysis
            print(f"📄 [ROUTE] Text detected. Skipping OCR for {fid}")
            response = s3_client.get_object(Bucket=bucket, Key=s3_key)
            raw_text = response['Body'].read().decode('utf-8')
            
            launch = lambda_client.invoke(
                FunctionName='analysis_worker',
                InvocationType='Event',
                Payload=json.dumps({"feedback_id": fid, "text": raw_text}).encode('utf-8')
            )
            print(f"🚀 [CHECKPOINT 2] Analysis Shortcut Launch: {launch['StatusCode']}")

        elif file_ext in ['jpg', 'jpeg', 'png']:
            # 📸 STANDARD: Needs OCR extraction first
            print(f"📸 [ROUTE] Image detected. Relaying to ocr_worker for {fid}")
            ocr_payload = {
                "feedback_id": fid,
                "Records": [{"s3": {"bucket": {"name": bucket}, "object": {"key": s3_key}}}]
            }
            
            launch = lambda_client.invoke(
                FunctionName='ocr_worker',
                InvocationType='Event',
                Payload=json.dumps(ocr_payload).encode('utf-8')
            )
            print(f"🚀 [CHECKPOINT 2] OCR Relay Launch: {launch['StatusCode']}")

        else:
            print(f"⚠️ [SKIP] Unsupported file extension: {file_ext}")

        return {"status": "success", "id": fid}

    except Exception as e:
        print(f"🛑 [FATAL ERROR] {str(e)}")
        return {"status": "error", "message": str(e)}