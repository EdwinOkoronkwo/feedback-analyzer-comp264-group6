import boto3
import json
import os
import requests

# Initialize Clients
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
lambda_client = boto3.client('lambda', region_name='us-east-1')

def get_mistral_summary(text, api_key):
    m_url = "https://api.mistral.ai/v1/chat/completions"
    prompt = f"Summarize this feedback in exactly 10 words: '{text}'"
    
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }
    
    payload = {
        "model": "mistral-medium-latest",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 50
    }

    try:
        # Check if key exists
        if not api_key:
            return "Error: Mistral API Key is missing in Lambda Env"

        res = requests.post(m_url, headers=headers, json=payload, timeout=10)
        res.raise_for_status()
        return res.json()['choices'][0]['message']['content'].strip()
    except Exception as e:
        # 🎯 This will now show up in your CloudWatch logs
        print(f"❌ DETAILED MISTRAL ERROR: {str(e)}")
        return f"Summary unavailable: {str(e)[:20]}"
        
def lambda_handler(event, context):
    fid = event.get('feedback_id')
    translated_text = event.get('text')
    mistral_key = os.environ.get('MISTRAL_API_KEY')

    print(f"🤖 Summarizer Worker: Requesting Mistral summary for {fid}")

    # 1. Get Mistral Summary
    summary = get_mistral_summary(translated_text, mistral_key)

    # 2. Update DynamoDB with the Summary
    dynamodb.Table('Analysis_Summaries').update_item(
        Key={'feedback_id': fid},
        UpdateExpression="SET summary = :s",
        ExpressionAttributeValues={':s': summary}
    )

    # 3. RELAY: Trigger Speech Worker
    lambda_client.invoke(
        FunctionName='speech_worker',
        InvocationType='Event',
        Payload=json.dumps({
            "feedback_id": fid, 
            "text": translated_text
        }).encode('utf-8')
    )

    return {"status": "success", "summary": summary}